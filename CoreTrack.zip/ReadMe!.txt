This software has made with python, and converted for exe, so the UI its bad, Sorry :(
Thank you for your attention <3