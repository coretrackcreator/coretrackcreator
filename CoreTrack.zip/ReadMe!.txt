This software was made with Python and converted to an EXE, so the UI (interface) is bad, sorry :(
Thank you for your attention <3

此软件是用 Python 制作的，并转换为 EXE，因此 UI（界面）较差，抱歉 :(
感谢您的关注 <3

यह सॉफ़्टवेयर Python के साथ बनाया गया है और EXE में परिवर्तित किया गया है, इसलिए UI (इंटरफ़ेस) अच्छा नहीं है, क्षमा करें :(
आपके ध्यान के लिए धन्यवाद <3

Diese Software wurde mit Python erstellt und in eine EXE konvertiert, daher ist die UI (Benutzeroberfläche) schlecht, sorry :(
Vielen Dank für Ihre Aufmerksamkeit <3

Это программное обеспечение создано на Python и преобразовано в EXE, поэтому интерфейс плохой, извините :(
Спасибо за ваше внимание <3

Este software foi feito com Python e convertido para EXE, então a interface (UI) está ruim, desculpe :(
Obrigado pela atenção <3

このソフトウェアはPythonで作成され、EXEに変換されたため、UI（インターフェース）が悪いです。申し訳ありません :(
ご注目いただきありがとうございます <3

Ce logiciel a été créé avec Python et converti en EXE, donc l'interface utilisateur (UI) est mauvaise, désolé :(
Merci pour votre attention <3